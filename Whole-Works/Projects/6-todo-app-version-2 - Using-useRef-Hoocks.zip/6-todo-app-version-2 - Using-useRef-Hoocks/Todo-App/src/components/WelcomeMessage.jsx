import styles from "./WelcomeMessage.module.css";
let WelcomeMessage = () => {
  return <h1 className={styles.welcome}>Enjoy Your Day</h1>;
};

export default WelcomeMessage;
